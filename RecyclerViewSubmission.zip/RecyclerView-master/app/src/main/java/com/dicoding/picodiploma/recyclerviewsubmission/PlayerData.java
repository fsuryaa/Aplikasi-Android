package com.dicoding.picodiploma.recyclerviewsubmission;

import java.util.ArrayList;

class PlayerData {
    private static String[] playerNames = {
            "Marc-Andre ter Stegen",
            "Ronald Araujo",
            "Marcos Alonso",
            "Pedri",
            "Robert Lewandowski",
            "Ousmane Dembele",
            "Ansu Fati",
            "Ferran Torres",
            "Raphinha",
            "Inaki Pena"
    };

    private static String[] playerDeskripsi = {
            "Marc-André ter Stegen, kiper berkebangsaan Jerman, telah meraih sejumlah prestasi gemilang dalam karirnya bersama Barcelona. Ia menjadi bagian penting dalam kesuksesan Barcelona meraih gelar La Liga pada beberapa musim, seperti 2014-15, 2015-2016, 2017-2018, 2018-2019, dan terbaru di musim 2022-2023. Selain itu, Ter Stegen juga berkontribusi dalam peraihan Piala Raja Spanyol pada tahun 2014-15, 2015-16, 2016-17, 2017-18, dan 2020-21. Ia juga turut serta dalam kemenangan Barcelona di Piala Super Spanyol pada tahun 2018 dan 2023, serta memperoleh sukses di tingkat Eropa dengan memenangkan Liga Champions UEFA pada musim 2014-15. Pencapaiannya juga mencakup kemenangan di Piala Super UEFA pada tahun 2015, yang menegaskan peran pentingnya dalam tim. Dengan prestasi-prestasi ini, Marc-André ter Stegen telah membuktikan dirinya sebagai salah satu kiper terkemuka dalam sepakbola modern dan menjadi aset berharga bagi Barcelona.",
            "Ronald Federico Araújo da Silva adalah seorang pemain sepak bola profesional Uruguay yang bermain sebagai bek tengah untuk klub La Liga Barcelona dan tim nasional Uruguay Ronald Federico Araújo da Silva, pemain FC Barcelona, menandatangani kontrak pada 29 Agustus 2018. Ia debut di La Liga pada 6 Oktober tahun berikutnya dan mencetak gol penting dalam beberapa pertandingan, termasuk El Clásico pada 20 Maret 2022. ",
            "Marcos Alonso Mendoza adalah seorang pemain sepak bola profesional asal Spanyol yang bermain pada posisi bek kiri atau bek tengah untuk klub La Liga Barcelona dan tim nasional Spanyol Marcos Alonso memulai kariernya bersama Real Madrid, tetapi dia mulai dikenal saat bermain di Inggris dengan Bolton Wanderers, kemudian melanjutkan karirnya di Serie A Italia bersama Fiorentina. Kesuksesannya bersama Fiorentina membuat Chelsea mendatangkannya dengan biaya sekitar £24 juta pada tahun 2016 Bersama Chelsea, Alonso tampil dalam lebih dari 100 pertandingan liga dan berhasil meraih berbagai gelar, termasuk Liga Utama Inggris, Piala FA, Liga Eropa UEFA, Piala Super UEFA, Liga Champions UEFA, dan Piala Dunia Antarklub FIFA. Setelah enam tahun dan lebih dari 200 penampilan dalam berbagai kompetisi, Alonso dan Chelsea memutuskan kontrak mereka pada September 2022 Kemudian, Alonso bergabung dengan Barcelona dengan menandatangani kontrak hingga akhir Juni 2023 dengan klausa pembelian sebesar €50 juta.",
            "Pedro González López, lebih dikenal sebagai Pedri, adalah seorang pemain sepak bola profesional asal Spanyol yang bermain sebagai gelandang tengah untuk Barcelona dan tim nasional Spanyol Dikenal karena kreativitas, visi, dan umpannya, Pedri dianggap sebagai salah satu pemain sepak bola muda paling menjanjikan di dunia dengan bakat serta keahliannya dalam sepak bola yang jarang dimiliki oleh anak seusianya.",
            "Robert Lewandowski adalah pemain sepak bola asal Polandia yang saat ini bermain sebagai penyerang pada klub La Liga FC Barcelona dan merupakan kapten tim nasional Polandia Lewandowski dianggap sebagai salah satu striker terbaik sepanjang masa, serta salah satu pemain tersukses dalam sejarah Bundesliga dan Bayern Munich. Dia telah mencetak lebih dari 600 gol karir senior untuk klub dan negara serta memecahkan rekor Gerd Müller seorang legenda sepak bola Jerman yang tidak terpecahkan selama 49 Tahun[2].",
            "Ousmane Dembélé adalah pemain sepak bola yang berasal dari Prancis yang bermain bagi Tim Nasional Sepakbola Prancis dan FC Barcelona Pada 25 Agustus 2017, klub La Liga Barcelona mengumumkan bahwa mereka telah mencapai kesepakatan untuk menandatangani Dembele seharga €105 juta ditambah tambahan €40 juta yang dilaporkan. Pada tanggal 28 Agustus, ia menjalani tes medis dan menandatangani kontrak lima tahun, dengan klausul pembeliannya ditetapkan sebesar €400 juta. Barcelona baru saja menjual Neymar ke Paris Saint-Germain seharga €222 juta, jadi kesepakatan itu membuat Dembélé menjadi pemain termahal kedua (dalam euro) , bersama dengan Paul Pogba . Rennes menerima laporan €20 juta dari Borussia Dortmund sebagai hasil dari penjualan, dan vreux 27 juga merupakan bagian dari biaya. Dia diberi nomor punggung 11 yang sebelumnya dikenakan oleh Neymar.",
            "Anssumane Ansu Fati Vieira adalah seorang pemain klub sepak bola Liga Utama Inggris Brighton & Hove Albion, dipinjam dari klub sepak bola La Liga Barcelona dan tim nasional Spanyol yang bermain sebagai Penyerang Sayap Ansu Fati bergabung dengan akademi FC Barcelona, La Masia, pada tahun 2012, ketika ia baru berusia sepuluh tahun. Pilihan ini mengikuti langkah kakaknya yang melakukan hal serupa setahun sebelumnya Pada 24 Juli 2019, Fati menandatangani kontrak profesional pertamanya dengan Barcelona dengan durasi hingga tahun 2022. Pada tanggal 25 Agustus, dia membuat debutnya di tim utama Barcelona dan juga di La Liga, saat ia masuk sebagai pemain pengganti Carles Pérez dalam kemenangan 5-2 melawan Real Betis. Saat itu, usianya adalah 16 tahun dan 298 hari, menjadikannya pemain termuda kedua yang pernah membuat debut di tim utama Barcelona, hanya terpaut 18 hari lebih tua daripada Vicenç Martínez pada tahun 1941 Pada tanggal 31 Agustus 2019, Ansu Fati mencetak gol pertamanya dalam pertandingan antara Barcelona dan Osasuna ketika usianya baru 16 tahun dan 304 hari. Dengan pencapaiannya ini, dia menjadi pencetak gol termuda untuk Barcelona dan pemain ketiga termuda dalam sejarah La Liga.",
            "Ferran Torres Garcia adalah pemain sepak bola profesional Spanyol yang bermain sebagai penyerang sayap untuk klub FC Barcelona dan tim nasional Spanyol. Ia telah mewakili Spanyol di berbagai tingkat junior dan melakukan debut di tim senior pada tahun 2020",
            "Raphael Dias Belloli, biasa dikenal sebagai Raphinha, adalah seorang pemain sepak bola profesional asal Brazil yang bermain sebagai gelandang Sayap untuk klub La Liga Barcelona dan tim nasional Brasil. Awalnya, Raphinha memulai karier profesionalnya dengan bergabung ke klub Portugal, Vitória Guimarães, pada bulan Februari 2016. Kemudian, ia melanjutkan perjalanan kariernya ke Sporting Lisbon pada bulan Mei 2018, sebuah klub terkenal di Portugal. Di Sporting Lisbon, ia mencapai kesuksesan dengan meraih gelar Piala Portugal dan Piala Liga Portugal selama dua musimnya. Selanjutnya, pada tahun 2019, Raphinha berpindah ke klub Prancis, Rennes, yang berkompetisi di liga top, Ligue 1. Bergabung dengan liga yang kompetitif ini menjadi langkah penting dalam kariernya Pada bulan Juli 2022, Raphinha mengambil langkah besar dengan bergabung ke Barcelona, salah satu klub terbesar di La Liga Spanyol. Bergabung dengan Barcelona adalah pengakuan atas kualitas dan kemampuan bermainnya yang luar biasa. Perjalanan karier Raphinha mencerminkan perkembangan yang luar biasa dari klub ke klub, dan ia terus menunjukkan peningkatan dalam permainannya. Ia telah menjadi salah satu pemain Brasil yang paling menonjol di Eropa.",
            "gnacio Iñaki Peña Sotorres, adalah pemain sepak bola profesional Spanyol yang bermain sebagai penjaga gawang untuk FC Barcelona B. Mengakui potensinya, Peña dipanggil ke skuad utama Barcelona pada tanggal 30 Oktober 2018, untuk pertandingan pertama babak 32 besar Copa del Rey melawan Cultural Leonesa. Ia bertindak sebagai cadangan untuk kiper utama Jasper Cillessen dalam pertandingan tersebut, meskipun ia tidak dimainkan dan hanya duduk di bangku cadangan dalam kemenangan tandang 1-0 Barcelona. Seiring berjalannya waktu, Peña masih beberapa kali berada di bangku cadangan skuad utama ketika baik Jasper Cillessen maupun kiper utama Marc-André ter Stegen absen karena cedera. Terus melanjutkan perannya sebagai cadangan kiper, Peña kembali menjadi bagian dari bangku cadangan skuad utama selama musim 2019-20, memberikan perlindungan untuk Neto yang absen karena cedera. Pada tanggal 6 Oktober 2020, Barcelona menggunakan opsi untuk memperpanjang kontrak Peña selama dua tahun tambahan, menunjukkan keyakinan klub pada potensinya."
    };

    private static int[] playerImages = {
            R.drawable.stegen,
            R.drawable.ronal,
            R.drawable.alonso,
            R.drawable.pendri,
            R.drawable.robert,
            R.drawable.dembele,
            R.drawable.ansu,
            R.drawable.tores,
            R.drawable.rapini,
            R.drawable.inaki
    };

    static ArrayList<Player> getListData(){
        ArrayList<Player> list = new ArrayList<>();
        for (int position = 0; position < playerNames.length; position++) {
            Player player = new Player();
            player.setName(playerNames[position]);
            player.setDeskripsi(playerDeskripsi[position]);
            player.setPhoto(playerImages[position]);
            list.add(player);
        }
        return list;
    }


}
